<?php
class Conexao{
	public static function pegarConexao(){
		$conexao = new PDO("mysql:host=fdb30.awardspace.net;dbname=3677390_bdmuseu","3677390_bdmuseu","1234567890p");
		$conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$conexao->exec("SET CHARACTER SET utf8");
		return $conexao;
	}
}